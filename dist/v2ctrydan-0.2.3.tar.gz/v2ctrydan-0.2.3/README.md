# V2C Trydan Package:

This is a package for connect the Trydan chager with ModbusTCP. You can find it here: <br>
[Pypi-V2CTRYDAN](https://pypi.org/project/v2ctrydan/) <br>
[GITHUB](https://github.com/jesusllorens79/v2ctrydan) <br>
[V2C-Website](https://v2charge.com/) 
